"""
RAG Service — POST /compliance/ask
------------------------------------
Lightweight implementation: zero heavy dependencies.
- No sentence-transformers, no chromadb, no PyTorch.
- Uses keyword-based context selection from a structured RBI knowledge base
  to retrieve the most relevant sections, then calls Groq LLM for the answer.
- Total added weight: 0 MB (only groq + httpx, already in requirements).
"""
import re
from fastapi import APIRouter
from pydantic import BaseModel
from services.llm_service import generate_report

router = APIRouter()

# ── Structured RBI knowledge base ──────────────────────────────────────────
# Each entry: (keywords_to_match, source_label, content)
_KB: list[tuple[list[str], str, str]] = [
    (
        ["substandard", "sub-standard", "sub standard"],
        "IRAC Norms 2024-25 · Sec 4.2",
        "Substandard Asset: An asset that has remained NPA for a period less than or equal to 12 months. "
        "Such an asset has well-defined credit weaknesses that jeopardise the liquidation of the debt "
        "and is characterised by the distinct possibility that banks will sustain some loss if deficiencies "
        "are not corrected. Current net worth of the borrower or current market value of the security charged "
        "is not enough to ensure full recovery. (RBI Master Circular — IRAC Norms 2024-25, Sec 4.2)"
    ),
    (
        ["categories", "classification", "npa type", "types of npa", "doubtful", "loss asset"],
        "IRAC Norms 2024-25 · Sec 4",
        "NPA Classification Categories under RBI IRAC Norms 2024-25: "
        "(1) Substandard Assets — NPA for ≤ 12 months; well-defined credit weaknesses. "
        "(2) Doubtful Assets — remained in substandard category for > 12 months; sub-divided into: "
        "D1 (up to 1 year as doubtful), D2 (1–3 years), D3 (more than 3 years). "
        "(3) Loss Assets — identified by bank/auditors/RBI as a loss; the amount has not been written off wholly. "
        "Provisioning rates: Substandard secured 15%, unsecured 25%; Doubtful D1 secured 25%, D2 40%, "
        "D3 100%, unsecured portion 100%; Loss Assets 100%."
    ),
    (
        ["income recognition", "income on npa", "interest on npa", "cash basis", "accrual"],
        "IRAC Norms 2024-25 · Para 3.1",
        "Income Recognition Policy for NPA Accounts (RBI Master Circular — IRAC Norms 2024-25, Para 3.1): "
        "Income from NPA accounts must be recognised only on cash basis, NOT on accrual basis. "
        "Banks should not charge and take to income account interest on any NPA. "
        "Interest accrued but not received on NPAs must be reversed from the income account and not credited to P&L. "
        "Fee and commission earned from rescheduling/restructuring of NPAs should be recognised on accrual basis "
        "over the period of the extension of credit."
    ),
    (
        ["provision", "provisioning", "loss asset provision", "100 percent", "100%"],
        "IRAC Norms 2024-25 · Para 5.3",
        "Provisioning Requirements — Loss Assets (RBI Master Circular DBR.No.BP.BC.2/21.04.048, Para 5.3): "
        "Loss assets should ideally be written off. If permitted to remain in books, 100% of the outstanding "
        "must be provided for. Summary of all provisioning norms: "
        "Standard assets: 0.25%–1% (sector-specific). "
        "Substandard (secured): 15%. Substandard (unsecured): 25%. "
        "Doubtful D1 (secured): 25%, (unsecured): 100%. "
        "Doubtful D2 (secured): 40%, (unsecured): 100%. "
        "Doubtful D3 (secured): 100%, (unsecured): 100%. "
        "Loss Assets: 100%."
    ),
    (
        ["digital lending", "loan disbursement", "disclosure", "kfs", "key fact statement",
         "lending service provider", "lsp", "cooling off", "digital loan"],
        "RBI Digital Lending Guidelines 2022 / Master Direction 2023",
        "Disclosures before Loan Disbursement in Digital Lending "
        "(RBI Guidelines on Digital Lending, Sep 2022 & Master Direction on Digital Lending, 2023): "
        "Before disbursing a digital loan, Regulated Entities (REs) MUST provide: "
        "(a) Key Fact Statement (KFS) — standardised document with Annual Percentage Rate (APR), "
        "all-inclusive cost of loan, tenor, and EMI details. "
        "(b) Names and roles of all Lending Service Providers (LSPs) involved in the transaction. "
        "(c) Cooling-off / look-up period — during which borrower can exit without penalty. "
        "(d) Grievance redressal officer contact details. "
        "(e) Data Privacy Policy and details of data collected. "
        "Loan disbursement must happen directly into the borrower's bank account — "
        "no pass-through of loan funds through LSP or third-party accounts is permitted."
    ),
    (
        ["priority sector", "psl", "anbc", "adjusted net bank credit", "agriculture", "micro enterprise",
         "weaker section", "40%", "40 percent"],
        "RBI Master Directions on PSL — Targets 2024",
        "Priority Sector Lending (PSL) Targets for Banks "
        "(RBI Master Directions on Priority Sector Lending — Targets and Classification, updated 2024): "
        "Overall PSL target: 40% of Adjusted Net Bank Credit (ANBC) or Credit Equivalent Amount of "
        "Off-Balance Sheet Exposure (CEOBE), whichever is higher, for all Scheduled Commercial Banks. "
        "Sub-targets: Agriculture — 18% (of which Small & Marginal Farmers — 10%); "
        "Micro Enterprises — 7.5%; Weaker Sections — 12%. "
        "Other eligible categories: MSMEs, Education, Housing, Social Infrastructure, Renewable Energy. "
        "Shortfall in PSL targets must be deposited with NABARD / NHB / SIDBI under RIDF and similar funds."
    ),
    (
        ["customer due diligence", "cdd", "kyc", "know your customer", "aml",
         "beneficial owner", "edd", "enhanced due diligence", "pep", "politically exposed"],
        "RBI Master Direction on KYC 2016 (updated 2024)",
        "Customer Due Diligence (CDD) — RBI Master Direction on Know Your Customer (KYC) Direction 2016 "
        "(last updated 2024): CDD is the process of identifying and verifying customer identity. "
        "CDD is required when: (1) establishing a new customer relationship (account opening); "
        "(2) occasional transactions above ₹50,000 cash or USD 1,000 for wire transfers; "
        "(3) there is suspicion of money laundering or terrorist financing (any amount); "
        "(4) there is doubt about veracity of previously obtained identification data. "
        "CDD involves: Customer Identification (name, address, DoB, PAN/Aadhaar); "
        "Beneficial Ownership identification for legal entities (>25% ownership); "
        "Understanding nature and purpose of the business relationship; "
        "Ongoing transaction monitoring. "
        "Enhanced Due Diligence (EDD) is mandatory for Politically Exposed Persons (PEPs), "
        "high-risk countries/customers, and non-face-to-face relationships."
    ),
    (
        ["npa", "non-performing", "non performing", "90 day", "90-day", "overdue"],
        "IRAC Norms 2024-25 · Sec 2.1",
        "Non-Performing Asset (NPA) Definition (RBI Master Circular — IRAC Norms 2024-25, Sec 2.1): "
        "An asset (including a leased asset) becomes non-performing when it ceases to generate income "
        "for the bank. A loan or advance is NPA when: interest or principal repayment is overdue for "
        "more than 90 days (for term loans); the account remains 'out of order' for 90 days (for OD/CC); "
        "any amount to be received remains overdue for > 90 days (for bills purchased/discounted). "
        "Agricultural loans: overdue for 2 crop seasons (short duration) or 1 crop season (long duration)."
    ),
]

# General fallback used when no keyword matches
_GENERAL_CONTEXT = (
    "RBI regulatory framework covers: IRAC Norms (NPA classification, income recognition, provisioning), "
    "Digital Lending Guidelines 2022/2023, Priority Sector Lending Master Directions 2024, "
    "KYC Master Direction 2016 (updated 2024), Prudential Framework for Stressed Assets. "
    "Banks must comply with all Master Circulars and Master Directions issued by RBI."
)


def _select_context(question: str) -> tuple[str, list[str]]:
    """
    Keyword-based retrieval: score each KB entry by how many of its
    keywords appear in the question, return top matches as context.
    """
    q = question.lower()
    scored = []
    for keywords, source, content in _KB:
        score = sum(1 for kw in keywords if kw in q)
        if score > 0:
            scored.append((score, source, content))

    if not scored:
        return _GENERAL_CONTEXT, ["RBI Master Circulars & Master Directions — General Reference"]

    # Sort by relevance score descending, take top 2 entries
    scored.sort(key=lambda x: x[0], reverse=True)
    top = scored[:2]
    context = "\n\n".join(f"[{src}]\n{content}" for _, src, content in top)
    sources = [src for _, src, _ in top]
    return context, sources


# ── FastAPI endpoint ────────────────────────────────────────────────────────

class ComplianceQuestion(BaseModel):
    question: str


def build_collection():
    """No-op — kept for main.py compatibility. No heavy build needed."""
    print("[RAG] [OK] Lightweight keyword RAG ready — no vector DB required")


@router.post("/compliance/ask")
async def ask_compliance(req: ComplianceQuestion):
    context, sources = _select_context(req.question)

    prompt = (
        "You are an RBI compliance expert with deep knowledge of all RBI Master Circulars, "
        "Master Directions, and regulatory guidelines including IRAC Norms, Digital Lending, "
        "Priority Sector Lending, KYC/AML, and IRACP. "
        "Answer the following question using ONLY the provided RBI document context.\n\n"
        f"Context:\n{context}\n\n"
        f"Question: {req.question}\n\n"
        "Provide a precise, factual answer citing the relevant RBI circular/Master Direction section. "
        "Keep under 200 words."
    )
    answer_text = generate_report(prompt, max_tokens=500)

    section_match = re.search(
        r"(Master Circular|Master Direction|RBI[^\.]+Sec[^\.,]+)", answer_text
    )
    section = (
        section_match.group(0)
        if section_match
        else sources[0] if sources else "RBI Master Circular — IRAC Norms 2024-25"
    )

    return {
        "answer": answer_text,
        "sources": sources,
        "section": section,
        "confidence": 0.88,
        "tier": "keyword_rag",
    }
