"""
compliance_rag.py
------------------
Lightweight query interface for the pre-built RBI compliance index.
This is what your FastAPI app imports — it does NOT rebuild or re-embed
anything, it just loads the persistent index created by build_index.py
and answers queries against it.

Setup:
    1. Run build_index.py once (or after adding/updating source PDFs).
    2. Make sure the resulting 'compliance_db' folder sits alongside this file
       (or update DB_PATH below to point at it).
    3. Set GROQ_API_KEY as an environment variable.
"""

import os
import chromadb
from sentence_transformers import SentenceTransformer
from groq import Groq

DB_PATH = "./compliance_db"
COLLECTION_NAME = "rbi_compliance"
EMBEDDING_MODEL = "all-MiniLM-L6-v2"

GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "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")

# ── loaded once at import time, reused across requests ──────────
_embedder = SentenceTransformer(EMBEDDING_MODEL)
_groq_client = Groq(api_key=GROQ_API_KEY)
_chroma_client = chromadb.PersistentClient(path=DB_PATH)
_collection = _chroma_client.get_collection(name=COLLECTION_NAME)


def retrieve(query: str, top_k: int = 8):
    query_embedding = _embedder.encode(query).tolist()
    results = _collection.query(
        query_embeddings=[query_embedding],
        n_results=top_k,
    )
    docs = results["documents"][0]
    metas = results["metadatas"][0]
    return docs, metas


def answer(query: str) -> dict:
    """
    Returns a dict rather than printing, since this now gets called
    from an API endpoint instead of a notebook cell.
    """
    chunks_retrieved, metas = retrieve(query)
    context = "\n\n".join(
        f"[Source: {m['source']}]\n{c}" for c, m in zip(chunks_retrieved, metas)
    )

    prompt = f"""You are an RBI compliance expert.
Answer the question using ONLY the context provided below.
If the answer is not in the context, say "Not found in document."
Cite which source file(s) you used.

CONTEXT:
{context}

QUESTION: {query}

Give a clear, concise answer with relevant section references if available."""

    response = _groq_client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
    )

    return {
        "query": query,
        "answer": response.choices[0].message.content,
        "sources": sorted(set(m["source"] for m in metas)),
    }


if __name__ == "__main__":
    # quick manual test: python compliance_rag.py
    result = answer("What is the income recognition policy for NPA accounts?")
    print(result)
