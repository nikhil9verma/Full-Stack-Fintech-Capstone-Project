"""
Lightweight feature-importance utilities — no shap/scipy/numba required.
Uses the model's built-in feature_importances_ (tree models) with a
sign derived from the input values vs. their medians, giving a fast,
dependency-free approximation of SHAP-style directional factors.
"""
import numpy as np
import pandas as pd
from typing import Any, List, Dict


def get_top_factors(
    model: Any,
    data: pd.DataFrame,
    feature_names: List[str],
    n: int = 5,
) -> List[Dict[str, float]]:
    """
    Return top-N feature importance factors with directional sign.
    Works with any sklearn/xgboost tree model that exposes
    feature_importances_. Falls back to zero-values on any error.
    """
    try:
        # --- get raw importances (always positive) ---
        importances = None

        # XGBoost / sklearn tree ensembles
        if hasattr(model, "feature_importances_"):
            importances = np.array(model.feature_importances_, dtype=float)

        # sklearn Pipeline: unwrap the last estimator
        elif hasattr(model, "steps"):
            last = model.steps[-1][1]
            if hasattr(last, "feature_importances_"):
                importances = np.array(last.feature_importances_, dtype=float)

        if importances is None or len(importances) != len(feature_names):
            raise ValueError("feature_importances_ unavailable or length mismatch")

        # --- derive sign: above-median → positive impact, below → negative ---
        row = data.iloc[0].values.astype(float)
        # Use 0.5 as a neutral midpoint for already-normalised binary cols;
        # for continuous cols the sign tells us direction relative to midrange.
        signs = np.where(row >= 0.5, 1.0, -1.0)

        signed = importances * signs

        factors = [
            {"feature": feature_names[i], "value": round(float(signed[i]), 4)}
            for i in range(len(feature_names))
        ]
        factors.sort(key=lambda x: abs(x["value"]), reverse=True)
        return factors[:n]

    except Exception:
        # Graceful fallback — return zeroed placeholders
        return [{"feature": f, "value": 0.0} for f in feature_names[:n]]
